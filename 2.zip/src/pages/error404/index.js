import React from 'react';
import E404 from '~c/errors/404';

export default function(){
    return (
        <E404/>
    );
}