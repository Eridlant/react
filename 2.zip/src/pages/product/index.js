import React from 'react';

export default function(props){
  return (
    <>
      Post #{props.match.params.url}
    </>
  );
}