import React from 'react';
import ReactDom from 'react-dom';
import App from './app';

//import App from './app-simple.js';
// import 'bootstrap/dist/css/bootstrap.min.css';

ReactDom.render(<App/>, document.querySelector('#app'));

